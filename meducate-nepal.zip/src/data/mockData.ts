export interface BlogPost {
  id: string;
  title: string;
  shortDescription: string;
  content: {
    introduction: string;
    explanation: string;
    keyPoints: string[];
    nepalSpecificNotes: string;
  };
  category: string;
  createdAt: string; // ISO Date String
  imageUrl: string;
}

export const blogs: BlogPost[] = [
  {
    id: "1",
    title: "OTC Medicines in Nepal: Safe Usage and Risks",
    shortDescription: "A guide on using Paracetamol, ORS, and Cetirizine safely in Nepal without a prescription.",
    category: "Medicine Education",
    createdAt: new Date().toISOString(),
    imageUrl: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    content: {
      introduction: "Over-the-counter (OTC) medicines are widely available in Nepal, helping people treat minor ailments quickly. While they are accessible without a prescription, misusing them can lead to serious health complications.",
      explanation: "Common OTCs include Paracetamol (for fever and pain), ORS (Jeevan Jal for dehydration), and Cetirizine (for allergies). Paracetamol is safe when used in correct doses, but excessive use can cause liver damage. ORS is a lifesaver during diarrhea but must be mixed exactly as instructed on the packet. Cetirizine helps with cold and allergies but can cause drowsiness, making it unsafe before driving.",
      keyPoints: [
        "Always follow the dosage instructions on the packaging.",
        "Do not exceed 4 grams (8 tablets of 500mg) of Paracetamol in 24 hours.",
        "Check expiry dates before buying any medicine from a local pharmacy.",
        "Never take medications meant for adults and give them to children in half-doses without a doctor's advice."
      ],
      nepalSpecificNotes: "In rural areas of Nepal, some cold medicines might contain hidden Paracetamol. Taking these along with a separate Paracetamol tablet can easily lead to an overdose. Always consult the local pharmacist (ausadhi pasale) properly."
    }
  },
  {
    id: "2",
    title: "Antibiotics & Resistance: A Growing Threat",
    shortDescription: "What antibiotics are, why resistance happens, and the specific misuse problem in Nepal.",
    category: "Disease Awareness",
    createdAt: new Date().toISOString(),
    imageUrl: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    content: {
      introduction: "Antibiotics are life-saving medications that kill or stop the growth of bacteria. However, they are completely ineffective against viral infections like the common cold or the flu.",
      explanation: "Antibiotic resistance happens when bacteria change and find ways to survive the medicines designed to kill them. This turns curable infections into dangerous, potentially fatal diseases. When people stop an antibiotic course early because they 'feel better', the strongest bacteria survive and multiply, creating 'superbugs'.",
      keyPoints: [
        "Only use antibiotics prescribed by a certified healthcare professional.",
        "Never use leftover antibiotics from a previous illness.",
        "Always complete the full prescription, even if you feel better.",
        "Antibiotics do not cure viral infections like the common cold."
      ],
      nepalSpecificNotes: "In many parts of Nepal, it is unfortunately easy to buy antibiotics without a proper prescription. People often self-medicate for mild fevers with Azithromycin or Amoxicillin. This severe misuse is leading to a silent epidemic of untreatable infections across local hospitals."
    }
  },
  {
    id: "3",
    title: "Healthy Fruits for Everyday Nutrition",
    shortDescription: "Understanding the health benefits of Apple (स्याउ), Banana (केरा), and Papaya (पपीता).",
    category: "Nutrition Info",
    createdAt: new Date().toISOString(),
    imageUrl: "https://images.unsplash.com/photo-1610832958506-aa56368176cf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    content: {
      introduction: "Fruits are natural sources of essential vitamins and minerals. Including locally available fruits in your daily diet is one of the easiest ways to boost immunity and prevent chronic diseases.",
      explanation: "Let's explore three easily available fruits: \n1. Apple (स्याउ): Rich in fiber and antioxidants, excellent for heart health. \n2. Banana (केरा): High in potassium, making it a great energy booster and good for blood pressure control. \n3. Papaya (पपीता): Contains papain enzyme which helps in digestion, and Vitamin A for good vision.",
      keyPoints: [
        "Aim for at least one seasonal fruit a day.",
        "Whole fruits are better than fruit juices as they contain essential fiber.",
        "Bananas (केरा) are an excellent, affordable daily snack giving instant energy.",
        "Papaya (पपीता) is highly recommended for people suffering from constipation."
      ],
      nepalSpecificNotes: "While imported apples are common, locally grown varieties from Mustang and Jumla are incredibly nutritious. Bananas are grown extensively in the Terai region and are one of the most accessible and affordable sources of nutrition for all socio-economic groups."
    }
  }
];

export interface DownloadItem {
  id: string;
  title: string;
  description: string;
  fileType: string;
  size: string;
  iconType: "pdf" | "image";
}

export const downloads: DownloadItem[] = [
  {
    id: "d1",
    title: "OTC Medicine Guide",
    description: "A comprehensive PDF guide on safely using over-the-counter medications in Nepali households.",
    fileType: "PDF",
    size: "2.4 MB",
    iconType: "pdf",
  },
  {
    id: "d2",
    title: "Antibiotics Awareness Sheet",
    description: "One-pager factsheet explaining antibiotic resistance and safe practices.",
    fileType: "PDF",
    size: "1.1 MB",
    iconType: "pdf",
  },
  {
    id: "d3",
    title: "Dengue Prevention Poster",
    description: "High-resolution poster illustrating 'Search and Destroy' methods for mosquitoes outdoors.",
    fileType: "Image",
    size: "4.5 MB",
    iconType: "image",
  }
];

export interface GalleryItem {
  id: string;
  imageUrl: string;
  title: string;
  description: string;
}

export const galleryItems: GalleryItem[] = [
  {
    id: "g1",
    imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    title: "Community Health Camp",
    description: "Meducate Nepal conducting a free health camp in a rural village.",
  },
  {
    id: "g2",
    imageUrl: "https://images.unsplash.com/photo-1542884748-2b87b36c6b90?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    title: "Awareness Campaign",
    description: "Distributing dengue prevention flyers during monsoon season.",
  },
  {
    id: "g3",
    imageUrl: "https://images.unsplash.com/photo-1511174511562-5f7f18b874f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    title: "Pharmacy Education",
    description: "Educating local pharmacists on spotting antibiotic misuse.",
  },
  {
    id: "g4",
    imageUrl: "https://plus.unsplash.com/premium_photo-1661778091807-cae65011689b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    title: "School Programs",
    description: "Teaching young students about hand hygiene and clean water.",
  },
  {
    id: "g5",
    imageUrl: "https://images.unsplash.com/photo-1631549916768-4119b2e5f926?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    title: "Nutritional Workshop",
    description: "Showing the importance of local fruits and vegetables.",
  },
  {
    id: "g6",
    imageUrl: "https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    title: "First Aid Training",
    description: "Basic first response training for community leaders.",
  }
];
