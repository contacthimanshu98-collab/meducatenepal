import { Mail, Phone, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="bg-[#E2E8F0] text-[#64748B] py-12 px-4 sm:px-6 lg:px-8 mt-auto font-sans font-[600]">
      <div className="max-w-[1024px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <Link to="/" className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 flex items-center justify-center overflow-hidden">
              <img src="/logo.png" alt="Meducate Nepal Logo" className="w-full h-full object-contain" />
            </div>
            <span className="text-[20px] font-[800] text-primary tracking-tight">Meducate Nepal</span>
          </Link>
          <p className="text-[12px] text-[#64748B] mb-6 max-w-xs font-[600] leading-relaxed">
            Empowering Nepal through simple, accurate health education. 
            Bridging the gap between medical knowledge and public awareness.
          </p>
        </div>

        <div>
          <h3 className="text-primary font-[800] mb-4 text-[14px] uppercase tracking-[0.5px]">Quick Links</h3>
          <ul className="space-y-2">
            <li><Link to="/" className="text-[12px] hover:text-secondary transition-colors">Home</Link></li>
            <li><Link to="/blogs" className="text-[12px] hover:text-secondary transition-colors">Blogs</Link></li>
            <li><Link to="/downloads" className="text-[12px] hover:text-secondary transition-colors">Downloads</Link></li>
            <li><Link to="/gallery" className="text-[12px] hover:text-secondary transition-colors">Gallery</Link></li>
            <li><Link to="/contact" className="text-[12px] hover:text-secondary transition-colors">Contact</Link></li>
          </ul>
        </div>

        <div>
           <h3 className="text-primary font-[800] mb-4 text-[14px] uppercase tracking-[0.5px]">Contact Us</h3>
           <ul className="space-y-3">
             <li className="flex items-start space-x-3 text-[12px]">
               <MapPin className="h-4 w-4 text-secondary shrink-0" />
               <span>Kathmandu, Bagmati Province, Nepal</span>
             </li>
             <li className="flex items-center space-x-3 text-[12px]">
               <Phone className="h-4 w-4 text-secondary shrink-0" />
               <span>+977 1-4200000</span>
             </li>
             <li className="flex items-center space-x-3 text-[12px]">
               <Mail className="h-4 w-4 text-secondary shrink-0" />
               <span>info@meducatenepal.org</span>
             </li>
           </ul>
        </div>
      </div>
      
      <div className="max-w-[1024px] mx-auto mt-12 pt-8 border-t border-[#cbd5e1] text-center text-[11px] font-[600] text-[#64748B] flex flex-col md:flex-row justify-center items-center gap-4">
        <p>&copy; {new Date().getFullYear()} Meducate Nepal. All rights reserved.</p>
        <p className="hidden md:block">•</p>
        <p>Health License: NEP-4492-MED</p>
      </div>
    </footer>
  );
}
