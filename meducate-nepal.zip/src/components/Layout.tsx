import { Outlet } from "react-router-dom";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";

export function Layout() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow flex flex-col pt-20">
        {/* pt-20 to offset the fixed navbar */}
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
