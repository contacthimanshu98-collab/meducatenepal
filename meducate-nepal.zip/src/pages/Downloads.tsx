import { Download, FileText, Image as ImageIcon } from "lucide-react";
import { downloads } from "../data/mockData";
import { motion } from "motion/react";

export function Downloads() {
  return (
    <div className="w-full bg-[#F8FAFC] min-h-screen py-10">
      <div className="max-w-[1024px] mx-auto px-6 lg:px-12">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-[36px] sm:text-[48px] font-[800] text-slate-900 mb-6 tracking-tight">Free Resources</h1>
          <p className="text-[18px] text-slate-600 leading-[1.6]">
            Download and share these materials in your community. Let's spread awareness, not diseases.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {downloads.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white border border-[#E2E8F0] rounded-[20px] p-6 shadow-sm hover:shadow-md transition-all group flex flex-col"
            >
              <div className="flex items-start justify-between mb-6">
                <div className={`p-4 rounded-[12px] flex items-center justify-center ${item.iconType === 'pdf' ? 'bg-red-50 text-red-500' : 'bg-blue-50 text-blue-500'}`}>
                  {item.iconType === 'pdf' ? <FileText className="h-6 w-6" /> : <ImageIcon className="h-6 w-6" />}
                </div>
                <span className="text-[10px] font-[700] uppercase tracking-[0.5px] text-slate-500 bg-slate-50 px-3 py-1 rounded-full border border-[#E2E8F0]">
                  {item.size}
                </span>
              </div>
              
              <h3 className="text-[16px] font-[800] text-slate-900 mb-2">{item.title}</h3>
              <p className="text-slate-600 text-[13px] mb-8 leading-[1.5] flex-grow">{item.description}</p>
              
              <button className="w-full flex items-center justify-center py-3 bg-secondary text-white rounded-[12px] font-[700] text-[13px] hover:bg-secondary-dark transition-colors shadow-sm">
                <Download className="mr-2 h-4 w-4" />
                Download {item.fileType}
              </button>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-br from-primary to-[#1e3a8a] rounded-[24px] p-8 sm:p-12 text-center text-white shadow-lg overflow-hidden relative">
           <div className="absolute inset-0 bg-white opacity-5 mix-blend-overlay z-0"></div>
           <div className="relative z-10">
             <h2 className="text-[24px] sm:text-[32px] font-[800] mb-4 tracking-tight">Want materials in local languages?</h2>
             <p className="text-[16px] text-white/90 mb-8 max-w-2xl mx-auto leading-[1.6]">
               We are working on translating all resources to Maithili, Bhojpuri, Tharu, and Tamang. Contact us if you'd like to volunteer!
             </p>
             <a href="/contact" className="inline-flex items-center justify-center bg-white text-primary font-[700] rounded-[12px] px-8 py-3 text-[14px] hover:bg-slate-50 transition-colors shadow-md">
               Get in touch
             </a>
           </div>
        </div>

      </div>
    </div>
  );
}
