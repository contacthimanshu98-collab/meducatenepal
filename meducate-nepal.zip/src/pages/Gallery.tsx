import { galleryItems } from "../data/mockData";
import { motion } from "motion/react";

export function Gallery() {
  return (
    <div className="w-full bg-[#F8FAFC] min-h-screen py-10">
      <div className="max-w-[1024px] mx-auto px-6 lg:px-12">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-[36px] sm:text-[48px] font-[800] text-slate-900 mb-6 tracking-tight">Our Impact in Action</h1>
          <p className="text-[18px] text-slate-600 leading-[1.6]">
            A glimpse into our ground-level awareness campaigns, health camps, and educational workshops across Nepal.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.4 }}
              className="group relative rounded-[20px] overflow-hidden shadow-sm hover:shadow-lg transition-all aspect-[4/3] bg-white cursor-pointer border border-[#E2E8F0]"
            >
              <img 
                src={item.imageUrl} 
                alt={item.title} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/95 via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <h3 className="text-[18px] font-[800] text-white mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  {item.title}
                </h3>
                <p className="text-[13px] text-white/90 leading-[1.5] translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75">
                  {item.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </div>
  );
}
