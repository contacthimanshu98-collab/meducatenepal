import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Calendar, Tag, AlertTriangle } from "lucide-react";
import { blogs } from "../data/mockData";

export function BlogDetail() {
  const { id } = useParams<{ id: string }>();
  const blog = blogs.find(b => b.id === id);

  if (!blog) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 px-4">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Article not found</h2>
        <Link to="/blogs" className="text-primary hover:underline inline-flex items-center">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to all articles
        </Link>
      </div>
    );
  }

  return (
    <div className="w-full bg-[#F8FAFC] min-h-screen py-10">
      <article className="max-w-[800px] mx-auto px-6 lg:px-12">
        
        <Link to="/blogs" className="text-secondary hover:text-secondary-dark inline-flex items-center mb-8 font-[700] text-[13px] uppercase tracking-[0.5px] transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to articles
        </Link>

        {/* Header */}
        <header className="mb-10">
          <div className="flex flex-wrap items-center gap-4 mb-6 text-[12px] font-[600] text-[#64748B] uppercase tracking-[0.5px]">
             <span className="flex items-center text-primary">
               <Tag className="mr-1.5 h-4 w-4" /> {blog.category}
             </span>
             <span className="flex items-center">
               <Calendar className="mr-1.5 h-4 w-4" /> {new Date(blog.createdAt).toLocaleDateString()}
             </span>
          </div>
          <h1 className="text-[36px] sm:text-[48px] font-[800] text-slate-900 leading-[1.1] mb-8 tracking-tight">
            {blog.title}
          </h1>
          <div className="w-full h-[300px] sm:h-[400px] rounded-[24px] overflow-hidden shadow-md">
            <img src={blog.imageUrl} alt={blog.title} className="w-full h-full object-cover" />
          </div>
        </header>

        {/* Content */}
        <div className="bg-white rounded-[24px] shadow-sm border border-[#E2E8F0] p-8 sm:p-12">
          <div className="prose prose-slate prose-lg max-w-none prose-headings:font-[800] prose-headings:tracking-tight prose-p:leading-[1.6]">
            
            <p className="text-[18px] text-slate-700 leading-[1.6] font-[600] mb-8">
              {blog.content.introduction}
            </p>

            <h2 className="text-[24px] font-[800] text-slate-900 mt-10 mb-4 tracking-tight">Understanding the basics</h2>
            <div className="whitespace-pre-line text-[16px] text-slate-600 leading-[1.6] mb-8">
              {blog.content.explanation}
            </div>

            <h2 className="text-[24px] font-[800] text-slate-900 mt-10 mb-6 tracking-tight">Key Points to Remember</h2>
            <ul className="space-y-4 mb-10">
              {blog.content.keyPoints.map((point, index) => (
                <li key={index} className="flex items-start">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-secondary text-white flex items-center justify-center text-[12px] font-[800] mr-4 mt-0.5">
                    {index + 1}
                  </span>
                  <span className="text-[16px] text-slate-600 leading-[1.6]">{point}</span>
                </li>
              ))}
            </ul>

            {/* Nepal Specific Callout */}
            <div className="mt-12 bg-amber-50 border border-amber-200 rounded-[20px] p-8">
              <div className="flex items-center gap-3 mb-4">
                <AlertTriangle className="h-6 w-6 text-amber-600" />
                <h3 className="text-[18px] font-[800] text-amber-900 m-0 tracking-tight">In the Context of Nepal</h3>
              </div>
              <p className="text-[16px] text-amber-800 m-0 leading-[1.6]">
                {blog.content.nepalSpecificNotes}
              </p>
            </div>

          </div>
        </div>

      </article>
    </div>
  );
}
