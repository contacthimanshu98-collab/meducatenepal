import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowRight, Search, Tag } from "lucide-react";
import { blogs } from "../data/mockData";

export function Blogs() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = ["All", ...Array.from(new Set(blogs.map(b => b.category)))];

  const filteredBlogs = blogs.filter(blog => {
    const matchesSearch = blog.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          blog.shortDescription.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || blog.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="w-full bg-[#F8FAFC] min-h-screen py-10">
      <div className="max-w-[1024px] mx-auto px-6 lg:px-12">
        
        <div className="mb-8 max-w-3xl">
          <h1 className="text-[36px] font-[800] text-slate-900 mb-4 tracking-tight">Health Education Articles</h1>
          <p className="text-[16px] text-slate-600 leading-[1.6]">
            Read our latest articles specifically curated for the Nepali community.
            Learn about common diseases, daily nutrition, and safe medicinal practices.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white p-6 rounded-[20px] shadow-sm border border-[#E2E8F0] mb-8">
          <div className="flex flex-col md:flex-row gap-6 justify-between items-center">
            {/* Search */}
            <div className="relative w-full md:w-96">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="text"
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="block w-full pl-11 pr-4 py-3 border border-[#E2E8F0] rounded-[12px] text-[14px] font-[500] bg-slate-50 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all"
              />
            </div>
            
            {/* Categories */}
            <div className="flex items-center space-x-3 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
              <Tag className="h-4 w-4 text-slate-400 shrink-0 hidden sm:block" />
              <div className="flex space-x-2">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`whitespace-nowrap px-4 py-2 rounded-[100px] text-[12px] font-[700] uppercase tracking-[0.5px] transition-colors ${
                      selectedCategory === cat 
                        ? "bg-primary text-white" 
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Blog Grid */}
        {filteredBlogs.length > 0 ? (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {filteredBlogs.map((blog) => (
               <motion.div 
                 key={blog.id} 
                 initial={{ opacity: 0, y: 20 }}
                 animate={{ opacity: 1, y: 0 }}
                 whileHover={{ y: -5 }}
                 className="bg-white rounded-[20px] overflow-hidden shadow-sm hover:shadow-md border border-[#E2E8F0] transition-all flex flex-col"
               >
                 <div className="h-48 overflow-hidden relative">
                   <img src={blog.imageUrl} alt={blog.title} className="w-full h-full object-cover" />
                 </div>
                 <div className="p-6 flex-grow flex flex-col">
                   <div className="flex items-center justify-between mb-4">
                     <span className="text-[10px] uppercase font-[800] tracking-[1px] text-secondary">
                        {blog.category}
                     </span>
                     <span className="text-[11px] font-[600] text-slate-400">{new Date(blog.createdAt).toLocaleDateString()}</span>
                   </div>
                   <h3 className="text-[18px] font-[800] text-slate-900 mb-2 line-clamp-2 leading-[1.3]">{blog.title}</h3>
                   <p className="text-slate-600 text-[13px] mb-6 line-clamp-3 leading-[1.5]">{blog.shortDescription}</p>
                   
                   <div className="mt-auto pt-4 border-t border-[#F1F5F9]">
                     <Link to={`/blog/${blog.id}`} className="text-primary font-[700] text-[13px] hover:text-primary-dark inline-flex items-center group">
                       CONTINUE READING <ArrowRight className="ml-1.5 h-3.5 w-3.5 transform group-hover:translate-x-1 transition-transform" />
                     </Link>
                   </div>
                 </div>
               </motion.div>
             ))}
           </div>
        ) : (
          <div className="text-center py-20">
            <h3 className="text-xl font-medium text-slate-900 mb-2">No articles found</h3>
            <p className="text-slate-500">Try adjusting your search or category filters.</p>
          </div>
        )}

      </div>
    </div>
  );
}
