import React, { useState } from "react";
import { Mail, MapPin, Phone, Send } from "lucide-react";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setFormData({ name: "", email: "", message: "" });
      setTimeout(() => setIsSuccess(false), 5000);
    }, 1500);
  };

  return (
    <div className="w-full bg-[#F8FAFC] min-h-screen py-10">
      <div className="max-w-[1024px] mx-auto px-6 lg:px-12">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-[36px] sm:text-[48px] font-[800] text-slate-900 mb-6 tracking-tight">Get in Touch</h1>
          <p className="text-[18px] text-slate-600 leading-[1.6]">
            Have questions about health practices? Want to collaborate or volunteer? We'd love to hear from you.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Contact Info */}
          <div>
            <h2 className="text-[20px] font-[800] text-slate-900 mb-8 tracking-tight">Contact Information</h2>
            <div className="space-y-6">
              <div className="flex items-start bg-white border border-[#E2E8F0] p-6 rounded-[20px] shadow-sm">
                <div className="flex-shrink-0 bg-blue-50 p-3 rounded-[12px] text-primary">
                  <MapPin className="h-5 w-5" />
                </div>
                <div className="ml-5 flex flex-col justify-center">
                  <h3 className="text-[14px] font-[800] uppercase text-primary tracking-[0.5px]">Head Office</h3>
                  <p className="mt-1 text-[14px] text-slate-600 font-[500] leading-[1.5]">
                    Kathmandu Metro-11<br />
                    Bagmati Province, Nepal
                  </p>
                </div>
              </div>

              <div className="flex items-start bg-white border border-[#E2E8F0] p-6 rounded-[20px] shadow-sm">
                <div className="flex-shrink-0 bg-green-50 p-3 rounded-[12px] text-secondary">
                  <Phone className="h-5 w-5" />
                </div>
                <div className="ml-5 flex flex-col justify-center">
                  <h3 className="text-[14px] font-[800] uppercase text-secondary tracking-[0.5px]">Phone & WhatsApp</h3>
                  <p className="mt-1 text-[14px] text-slate-600 font-[500] leading-[1.5]">+977 1-4200000</p>
                  <p className="text-[14px] text-slate-600 font-[500] leading-[1.5]">+977 9800000000</p>
                </div>
              </div>

              <div className="flex items-start bg-white border border-[#E2E8F0] p-6 rounded-[20px] shadow-sm">
                <div className="flex-shrink-0 bg-teal-50 p-3 rounded-[12px] text-teal-600">
                  <Mail className="h-5 w-5" />
                </div>
                <div className="ml-5 flex flex-col justify-center">
                  <h3 className="text-[14px] font-[800] uppercase text-teal-700 tracking-[0.5px]">Email</h3>
                  <p className="mt-1 text-[14px] text-slate-600 font-[500] leading-[1.5]">info@meducatenepal.org</p>
                  <p className="text-[14px] text-slate-600 font-[500] leading-[1.5]">volunteer@meducatenepal.org</p>
                </div>
              </div>
            </div>

            {/* Social Proof/Disclaimer */}
            <div className="mt-8 p-6 bg-amber-50 rounded-[20px] border border-amber-200">
              <p className="text-[13px] text-amber-800 leading-[1.6]">
                <strong className="font-[800]">Note:</strong> We are a health education NGO. While we provide medical information, we do not provide personal diagnostics over email. For medical emergencies, please visit the nearest hospital.
              </p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-[24px] shadow-sm border border-[#E2E8F0] p-8 sm:p-10">
             <form onSubmit={handleSubmit} className="space-y-6">
               <div>
                 <label htmlFor="name" className="block text-[13px] font-[700] text-slate-800 mb-2 uppercase tracking-[0.5px]">Full Name</label>
                 <input
                   type="text"
                   id="name"
                   required
                   value={formData.name}
                   onChange={(e) => setFormData({...formData, name: e.target.value})}
                   className="w-full px-4 py-3.5 rounded-[12px] border border-[#E2E8F0] focus:ring-2 focus:ring-primary focus:border-primary transition-colors bg-slate-50 focus:bg-white text-[14px]"
                   placeholder="Aayush Shrestha"
                 />
               </div>
               
               <div>
                 <label htmlFor="email" className="block text-[13px] font-[700] text-slate-800 mb-2 uppercase tracking-[0.5px]">Email Address</label>
                 <input
                   type="email"
                   id="email"
                   required
                   value={formData.email}
                   onChange={(e) => setFormData({...formData, email: e.target.value})}
                   className="w-full px-4 py-3.5 rounded-[12px] border border-[#E2E8F0] focus:ring-2 focus:ring-primary focus:border-primary transition-colors bg-slate-50 focus:bg-white text-[14px]"
                   placeholder="aayush@example.com"
                 />
               </div>

               <div>
                 <label htmlFor="message" className="block text-[13px] font-[700] text-slate-800 mb-2 uppercase tracking-[0.5px]">Your Message</label>
                 <textarea
                   id="message"
                   rows={5}
                   required
                   value={formData.message}
                   onChange={(e) => setFormData({...formData, message: e.target.value})}
                   className="w-full px-4 py-3.5 rounded-[12px] border border-[#E2E8F0] focus:ring-2 focus:ring-primary focus:border-primary transition-colors bg-slate-50 focus:bg-white resize-none text-[14px]"
                   placeholder="How can we help you?"
                 ></textarea>
               </div>

               <button
                 type="submit"
                 disabled={isSubmitting}
                 className="w-full flex items-center justify-center py-4 px-4 rounded-[12px] shadow-md text-[14px] font-[700] text-white bg-secondary hover:bg-secondary-dark focus:outline-none transition-colors"
               >
                 {isSubmitting ? (
                   <span className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
                 ) : (
                   <>
                     SEND MESSAGE
                     <Send className="ml-2 h-4 w-4" />
                   </>
                 )}
               </button>

               {isSuccess && (
                 <div className="p-4 bg-green-50 text-green-700 rounded-[12px] text-center text-[13px] font-[700] border border-green-200 tracking-wide">
                   Thank you! Your message has been sent successfully.
                 </div>
               )}
             </form>
          </div>
        </div>

      </div>
    </div>
  );
}
