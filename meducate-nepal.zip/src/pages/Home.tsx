import { Link } from "react-router-dom";
import { ArrowRight, ShieldCheck, Apple, Pill } from "lucide-react";
import { motion } from "motion/react";
import { blogs } from "../data/mockData";

export function Home() {
  const featuredBlogs = blogs.slice(0, 3); // Take top 3 for featured cards

  return (
    <div className="w-full max-w-[1024px] mx-auto px-6 lg:px-12 py-6">
      <main className="flex flex-col lg:grid lg:grid-cols-[1fr_340px] gap-6">
        {/* Left Content Area */}
        <div className="flex flex-col gap-6">
          {/* Hero Section */}
          <section className="bg-gradient-to-br from-primary to-[#1e3a8a] rounded-[24px] p-8 sm:p-12 text-white shadow-xl relative overflow-hidden flex flex-col justify-center">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1576091160550-2173ff9e5ee5?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80')] bg-cover bg-center opacity-10 mix-blend-multiply z-0"></div>
            
            <div className="relative z-10 flex flex-col">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/20 px-3.5 py-1.5 rounded-full text-[12px] font-[700] uppercase tracking-[1px] w-fit mb-6"
              >
                Public Health Awareness
              </motion.div>

              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-[36px] sm:text-[48px] leading-[1.1] font-[800] tracking-tight mb-6 max-w-[500px]"
              >
                Empowering Nepal Through Accurate Health Education.
              </motion.h1>

              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-[18px] opacity-90 leading-[1.6] mb-8 max-w-[440px]"
              >
                We bridge the gap between medical complexity and community understanding through simple, accessible, and evidence-based content for all Nepali citizens.
              </motion.p>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="flex flex-wrap gap-4"
              >
                <Link 
                  to="/blogs" 
                  className="bg-secondary text-white px-6 py-3 rounded-xl font-[700] text-[14px] hover:bg-secondary-dark transition-colors flex items-center justify-center shadow-lg"
                >
                  Read our Articles
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
                <Link 
                  to="/downloads" 
                  className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-6 py-3 rounded-xl font-[700] text-[14px] hover:bg-white/20 transition-colors flex items-center justify-center"
                >
                  Free Resources
                </Link>
              </motion.div>
            </div>
          </section>

          {/* Featured Topics Section (inside left column) */}
          <section className="bg-white border border-[#E2E8F0] rounded-[20px] p-6 sm:p-8">
            <div className="mb-6">
              <h2 className="text-[14px] font-[800] uppercase tracking-[0.5px] flex items-center justify-between text-slate-800">
                Focus Areas <span className="text-secondary">•</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <motion.div 
                whileHover={{ y: -2 }}
                className="bg-slate-50 border border-[#E2E8F0] rounded-[16px] p-5 shadow-sm flex flex-col gap-3"
              >
                <div className="w-10 h-10 bg-blue-100 text-primary rounded-lg flex items-center justify-center">
                  <Pill className="h-5 w-5" />
                </div>
                <h3 className="text-[15px] font-[700] text-primary">OTC Medicines</h3>
                <p className="text-[12px] opacity-80 leading-[1.4] text-slate-700">Learn safe usage and potential risks of medicines like Paracetamol and Cetirizine.</p>
                <Link to="/blogs" className="text-secondary font-[700] text-[12px] mt-auto inline-flex items-center hover:text-secondary-dark transition-colors">
                  Read More <ArrowRight className="ml-1 h-3 w-3" />
                </Link>
              </motion.div>

              <motion.div 
                whileHover={{ y: -2 }}
                className="bg-slate-50 border border-[#E2E8F0] rounded-[16px] p-5 shadow-sm flex flex-col gap-3"
              >
                <div className="w-10 h-10 bg-red-100 text-red-600 rounded-lg flex items-center justify-center">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <h3 className="text-[15px] font-[700] text-primary">Antibiotic Resistance</h3>
                <p className="text-[12px] opacity-80 leading-[1.4] text-slate-700">Understanding why misuse leads to global resistance and how we can prevent it.</p>
                <Link to="/blogs" className="text-secondary font-[700] text-[12px] mt-auto inline-flex items-center hover:text-secondary-dark transition-colors">
                  Read More <ArrowRight className="ml-1 h-3 w-3" />
                </Link>
              </motion.div>

              <motion.div 
                whileHover={{ y: -2 }}
                className="bg-slate-50 border border-[#E2E8F0] rounded-[16px] p-5 shadow-sm flex flex-col gap-3"
              >
                <div className="w-10 h-10 bg-green-100 text-secondary rounded-lg flex items-center justify-center">
                  <Apple className="h-5 w-5" />
                </div>
                <h3 className="text-[15px] font-[700] text-primary">Nutrition <span className="font-serif italic text-primary ml-1">पोषण</span></h3>
                <p className="text-[12px] opacity-80 leading-[1.4] text-slate-700">Explore the benefits of local fruits like Papaya (पपीता) and Apple (स्याउ).</p>
                <Link to="/blogs" className="text-secondary font-[700] text-[12px] mt-auto inline-flex items-center hover:text-secondary-dark transition-colors">
                  Read More <ArrowRight className="ml-1 h-3 w-3" />
                </Link>
              </motion.div>
            </div>
          </section>
        </div>

        {/* Right Sidebar */}
        <aside className="flex flex-col gap-6">
          <div className="bg-white border border-[#E2E8F0] rounded-[20px] p-6 shadow-sm">
            <h2 className="text-[14px] font-[800] uppercase tracking-[0.5px] flex items-center justify-between text-slate-800 mb-4">
              Recent Awareness <span className="text-secondary">•</span>
            </h2>
            <div className="flex flex-col">
              {featuredBlogs.map((blog, index) => (
                <div key={blog.id} className={`py-4 flex flex-col gap-1.5 ${index !== featuredBlogs.length - 1 ? 'border-b border-slate-100' : ''}`}>
                  <div className="text-[10px] font-[700] text-secondary uppercase tracking-[0.5px]">{blog.category}</div>
                  <Link to={`/blog/${blog.id}`} className="text-[13px] font-[600] leading-[1.4] text-slate-800 hover:text-primary transition-colors">
                    {blog.title}
                  </Link>
                </div>
              ))}
            </div>
            <Link to="/blogs" className="text-[12px] font-[700] text-primary uppercase mt-4 block text-center hover:text-primary-dark transition-colors tracking-wide bg-slate-50 py-2 rounded-lg border border-slate-100">
              View All
            </Link>
          </div>

          <div className="bg-white border border-[#E2E8F0] rounded-[20px] p-6 shadow-sm">
            <h2 className="text-[14px] font-[800] uppercase tracking-[0.5px] flex items-center justify-between text-slate-800 mb-4">
              Resource Library <span className="text-secondary">•</span>
            </h2>
            <p className="text-[12px] opacity-80 leading-[1.4] text-slate-700 mb-4">
              Access downloadable PDF guides for community awareness campaigns and school programs.
            </p>
            <Link to="/downloads" className="bg-secondary text-white py-3 rounded-xl flex items-center justify-center font-[700] text-[13px] hover:bg-secondary-dark transition-colors shadow-md">
              Browse Downloads
            </Link>
          </div>
        </aside>
      </main>
    </div>
  );
}
